# Hangman
A Hangman game made with python using Tkinter library.
To run this game on your system follow steps given below.
1. Clone this repository
2. Make sure you have python 3 and Tkinter installed in your system
3. Select the directory Hangman and opent terminal in it.
4. Run the command 
```shell
python hangman.py 
```

Feel free to raise an issue if you found one. If you want to add any new feature to the game, go ahead make a PR.
