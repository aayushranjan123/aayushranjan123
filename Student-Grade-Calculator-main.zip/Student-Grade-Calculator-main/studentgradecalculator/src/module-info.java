/**
 * 
 */
/**
 * 
 */
module studentgradecalculator {
}