@extends('layouts.admin')
{{-- @extends('admin') --}}

@section('title')
    {{ __('Dashboard') }}
@endsection

@section('header')
  <h1 class="h3 mb-3">Dashboard</h1>
@endsection

@section('content')
  <section class="row">
    <div class="col-12">
      <div class="card flex-fill">
        <div class="card-header">
          <h5 class="card-title mb-0">Empty card</h5>
        </div>
        <div class="card-body">
        </div>
      </div>
    </div>
  </section>
@endsection

@section('script')
@endsection