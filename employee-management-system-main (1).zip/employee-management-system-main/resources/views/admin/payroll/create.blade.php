@extends('layouts.admin')

@section('title')
    {{ __('Employee Attendance') }}
@endsection

@section('content')
    <section class="row">
        <div class="col-12">
            <div class="card flex-fill">
                <div class="card-header">
                    <h5 class="card-title mb-0">{{ __('Employee Attendance') }}</h5>
                </div>
                
            </div>
        </div>
    </section>
@endsection

@section('script')
@endsection
