# 👋Hello DevOps Project - More doing, less reading

## 🤔 Who is this for?
* People with theoretical DevOps knowledge
* Beginners in DevOps

Start now!

[Your First Docker Container🐋](https://robusta-dev.github.io/Hello-DevOps-Project/projects/buildpythonlocally/yourfirstproject/)

## ✨Coming Soon

[Your First Kubernetes Pod](#)

[Your First Kubernetes ReplicaSet](#)

### by [Robusta.dev](https://home.robusta.dev/)
