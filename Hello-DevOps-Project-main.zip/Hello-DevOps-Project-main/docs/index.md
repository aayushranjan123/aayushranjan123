---
hide:
  - navigation
#   - toc
---
# 👋Hello DevOps Project - More doing, less reading

### Who is this for?
* People with theoretical DevOps knowledge
* Beginners in DevOps

Start now!

[Your First Docker Container :simple-docker:](./projects/buildpythonlocally/yourfirstproject.md){ .md-button .md-button--primary }

### Coming Soon

[Your First Kubernetes Pod](#){ .md-button }
[Your First Kubernetes ReplicaSet](#){ .md-button }

