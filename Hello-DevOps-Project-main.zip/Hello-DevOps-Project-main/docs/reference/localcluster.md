# K3s

Steps to install K3s locally

