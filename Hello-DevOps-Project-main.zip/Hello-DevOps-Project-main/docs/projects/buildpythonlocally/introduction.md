In this project, we will setup and run a simple python application that gets and displays memes from Reddit.
![Meme Generator](./images/memegeneratorexample.png)

## 🎯What you'll learn
* Writing a Dockerfile 
* Creating your first Docker image

## Prerequisites
* Python - You don't need to code
* Pip
* Docker
