import { Thread } from "@/components/ui/assistant-ui/thread";

export default function Home() {
  return (
    <main className="h-full">
      <Thread />
    </main>
  );
}
