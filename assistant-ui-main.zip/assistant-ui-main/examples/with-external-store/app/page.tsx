"use client";

import { Thread } from "@assistant-ui/react";

export default function Home() {
  return (
    <main className="h-full">
      <Thread />
    </main>
  );
}
