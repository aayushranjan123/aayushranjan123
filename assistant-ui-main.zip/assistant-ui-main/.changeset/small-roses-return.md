---
"@assistant-ui/react": minor
---

refactor!: drop deprecated features
