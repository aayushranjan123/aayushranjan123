---
"@assistant-ui/react": patch
---

feat: ThreadListItemPrimitive
