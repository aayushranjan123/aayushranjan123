# `@assistant-ui/react-hook-form`

React Hook Form integration for `@assistant-ui/react`.

Simply replace `useForm` with `useAssistantForm` to give the chatbot the ability to interact with your form.
