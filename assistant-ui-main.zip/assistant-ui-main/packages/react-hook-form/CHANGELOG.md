# @assistant-ui/react-hook-form

## 0.4.15

### Patch Changes

- 1ada091: chore: update deps
- Updated dependencies [cdcfe1e]
- Updated dependencies [cdcfe1e]
- Updated dependencies [94feab2]
- Updated dependencies [472c548]
- Updated dependencies [14da684]
- Updated dependencies [1ada091]
  - @assistant-ui/react@0.5.99

## 0.4.14

### Patch Changes

- ff5b86c: chore: update deps
- Updated dependencies [ff5b86c]
- Updated dependencies [ff5b86c]
- Updated dependencies [ff5b86c]
  - @assistant-ui/react@0.5.98

## 0.4.13

### Patch Changes

- d2375cd: build: disable bundling in UI package releases
- Updated dependencies [d2375cd]
  - @assistant-ui/react@0.5.93

## 0.4.12

### Patch Changes

- fb32e61: chore: update deps
- fb32e61: feat: react-19 support
- Updated dependencies [2090544]
- Updated dependencies [be04b5b]
- Updated dependencies [2090544]
- Updated dependencies [fb32e61]
- Updated dependencies [fb32e61]
  - @assistant-ui/react@0.5.90

## 0.4.11

### Patch Changes

- fb46305: chore: update dependencies
- Updated dependencies [fb46305]
- Updated dependencies [e225116]
- Updated dependencies [0ff22a7]
- Updated dependencies [378ee99]
- Updated dependencies [378ee99]
  - @assistant-ui/react@0.5.73

## 0.4.10

### Patch Changes

- 88957ac: feat: New unified Runtime API (part 1/n)
- Updated dependencies [88957ac]
- Updated dependencies [1a99132]
- Updated dependencies [3187013]
  - @assistant-ui/react@0.5.61

## 0.4.9

### Patch Changes

- 155d6e7: chore: update dependencies
- Updated dependencies [926dce5]
- Updated dependencies [155d6e7]
- Updated dependencies [f80226f]
  - @assistant-ui/react@0.5.60

## 0.4.8

### Patch Changes

- c348553: chore: update dependencies
- Updated dependencies [0f99aa6]
- Updated dependencies [c348553]
  - @assistant-ui/react@0.5.54

## 0.4.7

### Patch Changes

- 04f6fc8: chore: update deps
- Updated dependencies [04f6fc8]
  - @assistant-ui/react@0.5.50

## 0.4.6

### Patch Changes

- 554a423: chore: update deps
- Updated dependencies [554a423]
  - @assistant-ui/react@0.5.38

## 0.4.5

### Patch Changes

- 556001f: chore: update deps
- Updated dependencies [556001f]
- Updated dependencies [556001f]
  - @assistant-ui/react@0.5.29

## 0.4.4

### Patch Changes

- 134d39e: fix: undo moving internal utilities to /react/internal
- Updated dependencies [134d39e]
  - @assistant-ui/react@0.5.22

## 0.4.3

### Patch Changes

- 3cc67f2: refactor: move internal utilities to @assistant-ui/react/internal
- Updated dependencies [de04d92]
- Updated dependencies [3cc67f2]
  - @assistant-ui/react@0.5.20

## 0.4.2

### Patch Changes

- a216fbf: chore: update deps
- Updated dependencies [a216fbf]
  - @assistant-ui/react@0.5.9

## 0.4.1

### Patch Changes

- ee38c0c: feat: message status v2
- 2baa898: chore: v5
- Updated dependencies [ee38c0c]
- Updated dependencies [ee38c0c]
- Updated dependencies [2baa898]
  - @assistant-ui/react@0.5.1

## 0.3.2

### Patch Changes

- e220617: feat(runtimes/edge): client side API key, model name, model parameters specification
- Updated dependencies [bc77b4f]
- Updated dependencies [e220617]
  - @assistant-ui/react@0.4.6

## 0.3.1

### Patch Changes

- 998081b: fix: reduce specificity of built-in CSS styles
- Updated dependencies [998081b]
  - @assistant-ui/react@0.4.4

## 0.3.0

### Patch Changes

- Updated dependencies [e0e51cf]
- Updated dependencies [c7ba6a2]
- Updated dependencies [e0e51cf]
- Updated dependencies [e0e51cf]
- Updated dependencies [679cd54]
  - @assistant-ui/react@0.4.0

## 0.2.0

### Patch Changes

- Updated dependencies [3dd7384]
- Updated dependencies [23f474e]
- Updated dependencies [5b68f4a]
  - @assistant-ui/react@0.3.0

## 0.1.0

### Minor Changes

- 2ab2cab: feat!: experimental features are now marked as stable

### Patch Changes

- Updated dependencies [de20b1c]
- Updated dependencies [2ab2cab]
  - @assistant-ui/react@0.2.0

## 0.0.7

### Patch Changes

- 36f3a1f: chore: update dependencies
- Updated dependencies [36f3a1f]
- Updated dependencies [36f3a1f]
- Updated dependencies [36f3a1f]
  - @assistant-ui/react@0.1.7

## 0.0.6

### Patch Changes

- a6769d5: feat: ContentPartComponent types
- 86d4f7f: feat: add UseAssistantFormProps type
- Updated dependencies [a6769d5]
- Updated dependencies [52236ab]
  - @assistant-ui/react@0.1.6

## 0.0.4

### Patch Changes

- 671dc86: feat: Tool Render functions
- Updated dependencies [671dc86]
  - @assistant-ui/react@0.1.5

## 0.0.3

### Patch Changes

- 6e9528d: build: add changesets
- 6e9528d: feat: add useAssistantTool API
- Updated dependencies [6e9528d]
- Updated dependencies [6e9528d]
  - @assistant-ui/react@0.1.3
