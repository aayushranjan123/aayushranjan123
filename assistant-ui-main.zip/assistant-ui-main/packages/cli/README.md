# `assistant-ui` CLI

This package contains the command line interface for `assistant-ui`.

## Usage

```sh
npx assistant-ui@latest add
```
