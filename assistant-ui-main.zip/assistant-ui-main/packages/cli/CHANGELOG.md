# assistant-ui

## 0.0.18

### Patch Changes

- 1ada091: chore: update deps

## 0.0.17

### Patch Changes

- ff5b86c: chore: update deps

## 0.0.16

### Patch Changes

- d2375cd: build: disable bundling in UI package releases

## 0.0.15

### Patch Changes

- fb32e61: chore: update deps

## 0.0.14

### Patch Changes

- fb46305: chore: update dependencies

## 0.0.13

### Patch Changes

- d8bd40b: chore: update dependencies

## 0.0.12

### Patch Changes

- c438773: feat: allow disabling ComposerInput keyboard shortcuts
- e1ae3d0: chore: update dependencies

## 0.0.11

### Patch Changes

- 155d6e7: chore: update dependencies

## 0.0.10

### Patch Changes

- c348553: chore: update dependencies

## 0.0.9

### Patch Changes

- 7faa03b: cli: create -t langgraph

## 0.0.8

### Patch Changes

- 7d7bbce: fix: create command windows compatibility

## 0.0.7

### Patch Changes

- 9a55735: chore: update deps

## 0.0.6

### Patch Changes

- ab031a0: fix: make `create` directory argument optional

## 0.0.5

### Patch Changes

- 36f3a1f: chore: update dependencies
- 1f8cc5e: refactor: make cli package more lightweight
- 3810443: feat: npx assistant-ui create
