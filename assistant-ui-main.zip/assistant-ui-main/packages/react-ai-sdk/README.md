# `@assistant-ui/react-ai-sdk`

Vercel AI SDK integration for `@assistant-ui/react`.
