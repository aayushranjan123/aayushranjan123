export const SKIP_UPDATE = Symbol("skip-update");
export type SKIP_UPDATE = typeof SKIP_UPDATE;
