# `@assistant-ui/react-trieve`

Trieve integration for `@assistant-ui/react`.
