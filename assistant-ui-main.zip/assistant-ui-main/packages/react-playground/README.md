# `@assistant-ui/react-playground`

A playground runtime for `@assistant-ui/react`.
