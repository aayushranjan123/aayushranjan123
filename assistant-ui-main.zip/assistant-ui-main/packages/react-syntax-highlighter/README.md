# `@assistant-ui/react-syntax-highlighter`

`react-syntax-highlighter` integration for `@assistant-ui/react`.
