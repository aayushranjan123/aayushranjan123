export {
  makeSyntaxHighlighter,
  makeLightSyntaxHighlighter,
  makeLightAsyncSyntaxHighlighter,
  makePrismSyntaxHighlighter,
  makePrismLightSyntaxHighlighter,
  makePrismAsyncSyntaxHighlighter,
  makePrismAsyncLightSyntaxHighlighter,
} from "./react-syntax-highlighter";
