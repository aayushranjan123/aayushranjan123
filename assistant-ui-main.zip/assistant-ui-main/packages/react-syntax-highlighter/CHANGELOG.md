# @assistant-ui/react-syntax-highlighter

## 0.0.18

### Patch Changes

- 1ada091: chore: update deps
- Updated dependencies [cdcfe1e]
- Updated dependencies [cdcfe1e]
- Updated dependencies [94feab2]
- Updated dependencies [472c548]
- Updated dependencies [14da684]
- Updated dependencies [1ada091]
  - @assistant-ui/react@0.5.99
  - @assistant-ui/react-markdown@0.2.27

## 0.0.17

### Patch Changes

- ff5b86c: chore: update deps
- Updated dependencies [ff5b86c]
- Updated dependencies [ff5b86c]
- Updated dependencies [ff5b86c]
  - @assistant-ui/react-markdown@0.2.26
  - @assistant-ui/react@0.5.98

## 0.0.16

### Patch Changes

- d2375cd: build: disable bundling in UI package releases
- Updated dependencies [d2375cd]
  - @assistant-ui/react-markdown@0.2.23
  - @assistant-ui/react@0.5.93

## 0.0.15

### Patch Changes

- fb32e61: chore: update deps
- Updated dependencies [2090544]
- Updated dependencies [be04b5b]
- Updated dependencies [2090544]
- Updated dependencies [fb32e61]
- Updated dependencies [fb32e61]
  - @assistant-ui/react@0.5.90
  - @assistant-ui/react-markdown@0.2.20

## 0.0.14

### Patch Changes

- fb46305: chore: update dependencies
- Updated dependencies [fb46305]
- Updated dependencies [e225116]
- Updated dependencies [0ff22a7]
- Updated dependencies [378ee99]
- Updated dependencies [378ee99]
  - @assistant-ui/react-markdown@0.2.19
  - @assistant-ui/react@0.5.73

## 0.0.13

### Patch Changes

- 155d6e7: chore: update dependencies
- Updated dependencies [926dce5]
- Updated dependencies [155d6e7]
- Updated dependencies [f80226f]
  - @assistant-ui/react@0.5.60
  - @assistant-ui/react-markdown@0.2.14

## 0.0.12

### Patch Changes

- c348553: chore: update dependencies
- Updated dependencies [0f99aa6]
- Updated dependencies [c348553]
  - @assistant-ui/react@0.5.54
  - @assistant-ui/react-markdown@0.2.13

## 0.0.11

### Patch Changes

- 04f6fc8: chore: update deps
- Updated dependencies [04f6fc8]
  - @assistant-ui/react-markdown@0.2.12
  - @assistant-ui/react@0.5.50

## 0.0.10

### Patch Changes

- 554a423: chore: update deps
- Updated dependencies [554a423]
  - @assistant-ui/react-markdown@0.2.11
  - @assistant-ui/react@0.5.38

## 0.0.9

### Patch Changes

- 556001f: chore: update deps
- Updated dependencies [556001f]
- Updated dependencies [556001f]
  - @assistant-ui/react-markdown@0.2.10
  - @assistant-ui/react@0.5.29

## 0.0.8

### Patch Changes

- 134d39e: fix: undo moving internal utilities to /react/internal
- Updated dependencies [134d39e]
  - @assistant-ui/react-markdown@0.2.7
  - @assistant-ui/react@0.5.22

## 0.0.7

### Patch Changes

- 3cc67f2: refactor: move internal utilities to @assistant-ui/react/internal
- Updated dependencies [de04d92]
- Updated dependencies [3cc67f2]
  - @assistant-ui/react-markdown@0.2.6
  - @assistant-ui/react@0.5.20

## 0.0.6

### Patch Changes

- a216fbf: chore: update deps
- Updated dependencies [a216fbf]
  - @assistant-ui/react-markdown@0.2.3
  - @assistant-ui/react@0.5.9

## 0.0.5

### Patch Changes

- 2baa898: chore: v5
- Updated dependencies [ee38c0c]
- Updated dependencies [ee38c0c]
- Updated dependencies [2baa898]
  - @assistant-ui/react-markdown@0.2.1
  - @assistant-ui/react@0.5.1

## 0.0.3

### Patch Changes

- Updated dependencies [e0e51cf]
- Updated dependencies [c7ba6a2]
- Updated dependencies [e0e51cf]
- Updated dependencies [e0e51cf]
- Updated dependencies [679cd54]
  - @assistant-ui/react@0.4.0
  - @assistant-ui/react-markdown@1.0.0

## 0.0.2

### Patch Changes

- Updated dependencies [ef25706]
  - @assistant-ui/react-markdown@0.0.5
  - @assistant-ui/react@0.3.5
