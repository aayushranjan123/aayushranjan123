# `@assistant-ui/react-markdown`

`react-markdown` integration for `@assistant-ui/react`.
