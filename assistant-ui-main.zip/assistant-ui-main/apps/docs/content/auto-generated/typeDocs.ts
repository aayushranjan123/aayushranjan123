import { AssistantRuntimeProvider } from "@assistant-ui/react";
import { ComponentPropsWithRef } from "react";

export type AssistantRuntimeProvider = ComponentPropsWithRef<
  typeof AssistantRuntimeProvider
>;
