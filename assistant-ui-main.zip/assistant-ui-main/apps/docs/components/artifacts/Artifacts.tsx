export const Artifacts = () => {
  return (
    <iframe
      title="Artifacts Example"
      className="h-full w-full border-none"
      src="https://assistant-ui-artifacts.vercel.app/"
    />
  );
};
