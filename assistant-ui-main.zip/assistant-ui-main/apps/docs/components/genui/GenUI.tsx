export const GenUI = () => {
  return (
    <iframe
      title="Gen UI Example"
      className="h-full w-full border-none"
      src="https://assistant-ui-rsc-example.vercel.app/"
    />
  );
};
