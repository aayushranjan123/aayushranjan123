export * from "@/registry/assistant-ui/full/thread";
