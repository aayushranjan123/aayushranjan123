export * from "@/registry/assistant-ui/syntax-highlighter";
