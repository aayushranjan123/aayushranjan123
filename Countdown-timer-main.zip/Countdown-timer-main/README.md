# Countdown-timer

This is a simple countdown timer made using HTML, CSS, and Javascript. I used this video - https://www.youtube.com/watch?v=dtKciwk_si4 - as a reference.

Do check out how it looks here - https://prajaktasathe.github.io/Countdown-timer/ !! 😀
