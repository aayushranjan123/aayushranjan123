# Outspline - A highly modular and extensible outliner.
# Copyright (C) 2011 Dario Giovannetti <dev@dariogiovannetti.net>
#
# This file is part of Outspline.
#
# Outspline is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Outspline is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Outspline.  If not, see <http://www.gnu.org/licenses/>.

import json

from outspline.coreaux_api import Event

import queries
import databases
import items
import exceptions

check_pending_changes_event = Event()
reset_modified_state_event = Event()
history_event = Event()
history_insert_event = Event()
history_update_previous_event = Event()
history_update_parent_event = Event()
history_update_text_event = Event()
history_delete_event = Event()
history_clean_event = Event()


class DBHistory(object):
    def __init__(self, connection, items, filename):
        self.connection = connection
        self.items = items
        self.filename = filename

        self.hactions = {
            'insert': {
                'undo': self._do_history_row_delete,
                'redo': self._do_history_row_insert,
            },
            'update_previous': {
                'undo': self._do_history_row_update_previous,
                'redo': self._do_history_row_update_previous,
            },
            'update_parent': {
                'undo': self._do_history_row_update_parent,
                'redo': self._do_history_row_update_parent,
            },
            'update_text': {
                'undo': self._do_history_row_update_text,
                'redo': self._do_history_row_update_text,
            },
            'delete': {
                'undo': self._do_history_row_insert,
                'redo': self._do_history_row_delete,
            },
        }

        self.status_updates = {0: 1, 1: 0, 2: 3, 3: 2, 4: 5, 5: 4}

    def set_limits(self, soft, time, hard):
        self.historylimits = [soft, time, hard]

    def update_soft_limit(self, limit):
        qconn = self.connection.get()
        cur = qconn.cursor()
        cur.execute(queries.properties_update, (limit, ))
        self.connection.give(qconn)

        self.set_modified()

        self.historylimits[0] = limit

    def register_action_handlers(self, name, redo_handler, undo_handler):
        if name not in self.hactions:
            self.hactions[name] = {
                'undo': undo_handler,
                'redo': redo_handler,
            }
        else:
            raise exceptions.ConflictingActionHandlersError()

    def insert_history(self, group, id_, type_, description, query_redo,
                                                                query_undo):
        qconn = self.connection.get()
        cur = qconn.cursor()
        cur.execute(queries.history_insert, (group, id_, type_, description,
                                                    query_redo, query_undo))
        cur.execute(queries.history_delete_union, self.historylimits)
        self.connection.give(qconn)

    def get_next_history_group(self):
        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.history_delete_status)
        cursor.execute(queries.history_select_status_next)
        self.connection.give(qconn)

        row = cursor.fetchone()
        if row['H_group']:
            group = row['H_group'] + 1
        else:
            group = 1
        return group

    def get_history_descriptions(self):
        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.history_select_description)
        self.connection.give(qconn)

        # Putting the results in a dictionary loses record order

        return cursor

    def _update_history_id(self, id_, status):
        newstatus = self.status_updates[status]
        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.history_update_id, (newstatus, id_))
        self.connection.give(qconn)

    def check_pending_changes(self):
        check_pending_changes_event.signal(filename=self.filename)

        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.history_select_status)
        self.connection.give(qconn)

        row = cursor.fetchone()
        if row or self.modified:
            return True
        else:
            return False

    def set_modified(self):
        self.modified = True

    def reset_modified_state(self):
        self.modified = False

        reset_modified_state_event.signal(filename=self.filename)

    def read_history_undo(self):
        return self._read_history(queries.history_select_status_undo,
                                            queries.history_select_group_undo)

    def read_history_redo(self):
        return self._read_history(queries.history_select_status_redo,
                                            queries.history_select_group_redo)

    def _read_history(self, history_select_status_query,
                                                history_select_group_query):
        # SavedStatus  CurrentStatus  Status
        # 0 unsaved    0 undone       0 unsaved and undone
        # 0 unsaved    1 done         1 unsaved and done
        # 2 undone     0 undone       2 saved as undone
        # 2 undone     1 done         3 saved as undone but pending as done
        # 4 done       0 undone       4 saved as done but pending as undone
        # 4 done       1 done         5 saved as done

        # Possible scenarios:
        # 5
        # 5 4
        # 5 4 2
        # 5 4 2 0
        # 5 4 0
        # 5 3
        # 5 3 2
        # 5 3 2 0
        # 5 3 1
        # 5 3 1 0
        # 5 3 0
        # 5 2
        # 5 2 0
        # 5 1
        # 5 1 0
        # 5 0
        # 4
        # 4 2
        # 4 2 0
        # 4 0
        # 3
        # 3 2
        # 3 2 0
        # 3 1
        # 3 1 0
        # 3 0
        # 2
        # 2 0
        # 1
        # 1 0
        # 0

        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(history_select_status_query)
        self.connection.give(qconn)
        lastgroup = cursor.fetchone()

        if lastgroup:
            qconn = self.connection.get()
            cursorm = qconn.cursor()
            # Create a list, because it has to be looped twice
            history = tuple(cursorm.execute(history_select_group_query,
                                                    (lastgroup['H_group'], )))
            self.connection.give(qconn)
            return {'history': history,
                    'status': lastgroup['H_status']}
        else:
            return False

    def undo_history(self):
        self._do_history(self.read_history_undo(), 'undo')

    def redo_history(self):
        self._do_history(self.read_history_redo(), 'redo')

    def _do_history(self, read, action):
        if read:
            history = read['history']
            status = read['status']

            for row in history:
                self.hactions[row['H_type']][action](self.filename, action,
                            row[3], row['H_id'], row['H_type'], row['H_item'])
                self._update_history_id(row['H_id'], status)

            history_event.signal(filename=self.filename)

    def _do_history_row_insert(self, filename, action, jparams, hid, type_,
                                                                    itemid):
        parent, previous, text = json.loads(jparams)

        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.items_insert, (itemid, parent, previous, text))
        self.connection.give(qconn)

        self.items[itemid] = items.Item(self.connection, self, self.items,
                                                        self.filename, itemid)

        history_insert_event.signal(filename=self.filename, id_=itemid,
                        parent=parent, previous=previous, text=text, hid=hid)

    def _do_history_row_update_previous(self, filename, action, jparams, hid,
                                                                type_, itemid):
        parent, previous = json.loads(jparams)

        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.items_update_previous, (previous, itemid))
        self.connection.give(qconn)

        history_update_previous_event.signal(filename=self.filename,
                                id_=itemid, parent=parent, previous=previous)

    def _do_history_row_update_parent(self, filename, action, jparams, hid,
                                                                type_, itemid):
        oldparent, newparent, previous = json.loads(jparams)

        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.items_update_parent, (newparent, previous,
                                                                    itemid))
        self.connection.give(qconn)

        history_update_parent_event.signal(filename=self.filename, id_=itemid,
                oldparent=oldparent, newparent=newparent, previous=previous)

    def _do_history_row_update_text(self, filename, action, jparams, hid,
                                                                type_, itemid):
        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.items_update_text, (jparams, itemid))
        self.connection.give(qconn)

        history_update_text_event.signal(filename=self.filename, id_=itemid,
                                                                text=jparams)

    def _do_history_row_delete(self, filename, action, jparams, hid, type_,
                                                                    itemid):
        parent, text = json.loads(jparams)

        qconn = self.connection.get()
        cursor = qconn.cursor()
        cursor.execute(queries.items_delete_id, (itemid, ))
        self.connection.give(qconn)

        self.items[itemid].remove()

        history_delete_event.signal(filename=self.filename, id_=itemid,
                                            hid=hid, parent=parent, text=text)

    def clean_history(self):
        # This operation must be performed on a different connection than
        # the main one (which at this point has been closed already anyway)
        qconn = databases.FileDB(self.filename)
        cursor = qconn.cursor()

        cursor.execute(queries.history_delete_select,
                                                    (self.historylimits[0], ))
        # This won't be necessary anymore when bug #13 will be implemented
        cursor.execute(queries.history_update_group)

        history_clean_event.signal(filename=self.filename, dbcursor=cursor)

        qconn.save_and_disconnect()
