Do *not* try to run `setup.py` directly from this folder! A special release
procedure has to be followed in order to install Outspline from this GitHub
repository. If you are trying to install Outspline, follow
[Getting started](https://github.com/kynikos/outspline/wiki/Getting-started)
instead.
