Jenkins specifics
=====

This page contains information about use-cases specific to Jenkins.

NOTE: The page is under construction