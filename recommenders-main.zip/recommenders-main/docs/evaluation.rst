.. _evaluation:

Evaluation module
**************************

Python evaluation
===============================

.. automodule:: recommenders.evaluation.python_evaluation
    :members:

PySpark evaluation
===============================

.. automodule:: recommenders.evaluation.spark_evaluation
    :members:
    :special-members: __init__