# Student-Grade-ManagementSystem
Student Grade Management Project in C  This project is a simple command-line Student Grade Management System implemented in C language. It allows users to add, display, search, and delete student records. Each student record consists of a roll number, name, marks, and grade.
