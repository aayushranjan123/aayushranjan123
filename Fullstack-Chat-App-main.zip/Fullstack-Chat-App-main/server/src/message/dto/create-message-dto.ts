export class CreateMessageDto {
  channelId: string;
  userId: string;
  text: string;
  images: string[];
}
