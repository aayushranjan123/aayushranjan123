export class ChannelDto{
    participants:string[];
    admins?:string[];
    image:string;
    name:string;
    description:string;
}