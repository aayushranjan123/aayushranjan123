import styled from "styled-components"

export const Blurb = styled.div`
  background: black;
  width: 100%;
  padding: 10px 30px;
  color: white;
  text-align: center;
`
