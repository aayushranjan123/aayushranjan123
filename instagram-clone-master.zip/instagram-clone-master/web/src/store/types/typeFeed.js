export const GET_FEEDS = "GET_FEEDS";
export const LOADING_MORE = "LOADING_MORE";

export const DEFAULT_ERROR = "DEFAULT_ERROR";
export const LIKE_ERROR = "LIKE_ERROR";

export const COMMENT_POST = "COMMENT_POST";
export const COMMENT_ERROR = "COMMENT_ERROR";

export const FOLLOW_USER = "FOLLOW_USER";
export const FOLLOW_ERROR = "FOLLOW_ERROR";

export const DELETE_POST = "DELETE_POST";
export const DELETE_ERROR = "DELETE_ERROR";

export const ADD_FEED = "ADD_FEED";

export const EXIT_APP = "EXIT_APP";
