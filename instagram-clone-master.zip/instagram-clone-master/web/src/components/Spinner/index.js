import React from "react";

import { Spinner as StyleSpinner } from "./styles";

export default function Spinner() {
  return <StyleSpinner />;
}
