import React from "react";

import { Container } from "./styles";

export default function EmptyMessage({ message }) {
  return <Container>{message}</Container>;
}
