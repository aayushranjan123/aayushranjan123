import styled from "styled-components";

export const Container = styled.p`
  text-align: center;
  padding: 10px 10px;
  color: #e1e1e1;
  font-weight: bold;
  font-family: "Roboto";
`;
