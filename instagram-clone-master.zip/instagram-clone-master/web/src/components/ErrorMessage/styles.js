import styled from "styled-components";

export const Error = styled.p`
  color: #fc4850;
  font-family: "Roboto";
  font-size: 11px;
  margin-bottom: 5px;
`;
