declare let ige: IgeEngine;
declare let openChatBubble: any;
declare let _: any;
