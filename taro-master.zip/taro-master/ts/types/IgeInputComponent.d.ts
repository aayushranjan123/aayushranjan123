declare class IgeInputComponent extends IgeEventingClass {

	processInputOnEveryFps (): void
}