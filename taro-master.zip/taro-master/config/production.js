module.exports = {
	BE_URL: 'http://gs_manager.modd.io'
};
