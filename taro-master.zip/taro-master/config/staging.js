module.exports = {
	BE_URL: 'http://staging_gs_manager.modd.io'
};
