module.exports = {
	BE_URL: 'http://localhost:8081'
};
