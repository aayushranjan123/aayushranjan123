const videoChatConfig = {
	peerJSConfig: false,
	socketIOConfig: false
};