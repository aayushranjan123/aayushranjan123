# C-Chatbot
A simple chatbot written in c++

Allows user to ask the bot a question

If the bot knows the answer it will give the answer to the user.

If the bot does not know the answer, the bot will ask the user for the answer, and then store it for later use
