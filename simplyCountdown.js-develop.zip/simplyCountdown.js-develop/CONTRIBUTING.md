### Contributing
- Give it a [star](https://github.com/VincentLoy/simplyCountdown.js/stargazers) !
- [Report a bug](https://github.com/VincentLoy/simplyCountdown.js/issues)
- Tweet about it :)

#### Pull Requests
- **Solve a problem**
- For code enhancement, use [ESLint](https://eslint.org/) as a code quality tool.
- Small is better than Big.
