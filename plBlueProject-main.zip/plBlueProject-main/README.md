# plBlueProject

We consists of 3 members, 
Jonald J. Anda - Team Lead 
Andrew Nazreth P. CONTI - Project Engineer 
Markus Kyle Malicdem REALIN - Rapporteur


We made a Contact Book that can hold, create, edit, delete contact information from different programs of DBTC Mandaluyong.
It is useful for staffs and personnel of DBTC to use this tool to help them see easily the contacts of the persons working or studying in DBTC Mandaluyong.


Watching the link below, is a short summary of our work in order for you to have a small background on checking what is our project all about.

This is the Youtube Links of the Video Presentation made by the team for our #plBlueProject :
https://youtu.be/3ogJ34Gpt6E

Also this is the link for our DBTC Contact Book Poster :
https://imgur.com/d98PmaQ

This is the link for our User Manual for the DBTC Contact Book :
https://docs.google.com/document/d/1PO1QYWeTa1_EjDvYCuvgXa6cqtTWNNvQ32f0pQ2NXOc/edit?usp=sharing

This is the link of the User Manual of GOOGLE FILE DRIVE STREAM APP :
https://docs.google.com/document/d/1sUbfRNCGFxF4fujn3DwV1uATIC14jCVQzN6MICV82jc/edit?usp=sharing

This is the link of the User Manual of GOOGLE FILE DRIVE STREAM APP video tutorial:
https://www.youtube.com/watch?v=Qaob-BkiWw0
