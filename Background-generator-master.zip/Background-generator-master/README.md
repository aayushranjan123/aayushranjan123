# Background-generator
A simple web app that uses JS to dynamically change the background color of the page.
Fork the code or open the app using the link-https://shree998.github.io/Background-generator/. 
Based on the color selected the CSS Code for the color will be displayed on the page, copy it and paste it in your style.css file to have that color.
