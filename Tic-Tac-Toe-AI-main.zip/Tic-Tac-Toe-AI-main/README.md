![](https://img.shields.io/badge/Programming_Language-Python-blue.svg)
![](https://img.shields.io/badge/Tool_Used-Tkinter-gold.svg)
![](https://img.shields.io/badge/Game-Tic_Tac_Toe-yellow.svg)
![](https://img.shields.io/badge/Mode-AI-orange.svg)
![](https://img.shields.io/badge/Python_Version-3.7-brown.svg)
![](https://img.shields.io/badge/Status-Complete-green.svg)

<h3 align="center"> ❤️ Welcome Developers ❤️  </h3>

### <p align="center">  	😮 Introducing My New Game made in Python 	😮 </p>

<p align="center"><img src="game_gif.gif"></p>

###  <p align="center">	😲 Yes, This is an AI Tic-Tac-Toe Game made by Python(Version 3) Tkinter 	😲</p>

---

<h3 align="center"><b>🙄 But What Special 😳</b></h3>

<h3 align="center"> 😲 <i>You Can Play With Your Computer</i> 😲 </h3>
<h3 align="center">	😳<b> Special Facility</b> 😳</h3>
<h3 align="center">1. Machine Vs Human 👉  Machine get the first chance to play</h3>
<h3 align="center">2. Human Vs Machine 👉  Human Get the first chance to play</h3>
<h3 align="center"><b>Show 💘 by Starring this Repo</b></h3>

---
<h3 align="center">💡 <b>Important Links</b> 💡</h3>

- #### [Click Here to See the Project Video](https://youtu.be/eDpWs09ZGvI)

- #### [Follow Me on LinkedIn to Get Project Updates](https://www.linkedin.com/in/samarpan-dasgupta-4aa1061b0/ "LCO")

<h2 align="center"><b>❤️ Thank You For Visiting 🙏, Have a Nice Day ❤️</b></h2>
