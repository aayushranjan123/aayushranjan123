# TODO List in C++
This C++ program is a simple TODO list application that allows users to manage their tasks. It provides the following features:

- Add a new task
- Update an existing task
- Delete a task
- View all tasks
- Data persistence using file handling
<br></br>

## Contributing
Contributions are welcome! Feel free to fork the repository and submit pull requests to suggest improvements or add new features.
<br></br>

## License
This project is licensed under the MIT License - see the LICENSE file for details.

Feel free to suggest any improvements or contribute to the project!
