export interface UserDetails {
  name: string;
  email: string;
  photoURL: string;
  address: string;
  state: string;
  country: string;
  zip: string;
  birth: string;
  phone: string;
}
