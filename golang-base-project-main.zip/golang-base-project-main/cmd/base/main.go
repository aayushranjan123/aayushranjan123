package main

import baseproject "github.com/uberswe/golang-base-project"

func main() {
	baseproject.Run()
}
