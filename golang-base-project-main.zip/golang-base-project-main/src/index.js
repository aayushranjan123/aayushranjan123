// Collapse is needed for responsive navbar
import 'bootstrap/js/src/base-component'
import 'bootstrap/js/src/collapse'
import 'bootstrap/js/src/alert'