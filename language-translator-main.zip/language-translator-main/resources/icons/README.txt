## Icon Attribution

The icons used in this project were sourced from https://www.flaticon.com/

<a href="https://www.flaticon.com/free-icons/language" title="language icons">Language icons created by Freepik - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/translation" title="translation icons">Translation icons created by juicy_fish - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/translate" title="translate icons">Translate icons created by Smashicons - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/clear" title="clear icons">Clear icons created by Freepik - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/copy" title="copy icons">Copy icons created by Freepik - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/text-to-speech" title="text to speech icons">Text to speech icons created by Freepik - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/voice-recognition" title="voice-recognition icons">Voice-recognition icons created by Freepik - Flaticon</a>

