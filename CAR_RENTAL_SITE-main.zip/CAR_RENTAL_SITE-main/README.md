# CAR_RENTAL_SITE
An project using HTML , CSS and javascript to create a car rental website where we have the login ,sign-up, booking and feedback pages
