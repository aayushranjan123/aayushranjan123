# Online-Quiz

Online Quiz System is a Java-based examination system where quiz is taken Online i.e. through the internet or intranet using computer system. The purpose of Online Quiz System is to take Semester Quizzes in an efficient 
manner and no time wasting for checking the paper. The main objective of Online Quiz System is to efficiently evaluate the candidate through a fully automated system that not only saves lot of time but also gives fast results. 
