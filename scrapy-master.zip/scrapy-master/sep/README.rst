:orphan:

Scrapy Enhancement Proposals
============================

This folder contains Scrapy Enhancement Proposal. Most of them are in Trac Wiki
format because they were migrated from the old Trac.
