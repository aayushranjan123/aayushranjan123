package com.example.overmorrow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
