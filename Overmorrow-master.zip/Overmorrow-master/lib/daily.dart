/*
Copyright (C) <2025>  <Balint Maroti>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

*/

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:overmorrow/hourly.dart';
import 'package:overmorrow/new_forecast.dart';
import 'ui_helper.dart';


class buildDays extends StatefulWidget {
  final data;

  buildDays({Key? key, required this.data}) : super(key: key);

  @override
  _buildDaysState createState() => _buildDaysState(data);
}

class _buildDaysState extends State<buildDays> with AutomaticKeepAliveClientMixin {
  final data;

  late List<bool> expand = [];

  @override
  void initState() {
    super.initState();
    for (int i = 0; i < data.days.length; i++) {
      expand.add(false);
    }
  }

  void _onExpandTapped(int index) {
    setState(() {
      HapticFeedback.lightImpact();
      expand[index] = !expand[index];
    });
  }

  @override
  bool get wantKeepAlive => true;

  _buildDaysState(this.data);

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final int daysToShow = min(data.days.length, 7);
    return Padding(
      padding: const EdgeInsets.only(left: 24, right: 24, bottom: 25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 1, bottom: 14),
            child: comfortatext("daily", 17,
                data.settings,
                color: data.current.palette.onSurface),
          ),
          ListView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.only(top: 0, bottom: 0),
              physics: const NeverScrollableScrollPhysics(),
              itemCount: daysToShow,
              itemBuilder: (context, index) {
                final day = data.days[index];
                return Padding(
                  padding: const EdgeInsets.only(top: 3, bottom: 3),
                  child: Container(
                      decoration: BoxDecoration(
                          borderRadius:
                          index == 0 ? const BorderRadius.vertical(
                              top: Radius.circular(33),
                              bottom: Radius.circular(12))
                              : index == daysToShow - 1 ? const BorderRadius
                              .vertical(bottom: Radius.circular(33),
                              top: Radius.circular(12))
                              : BorderRadius.circular(12),
                          color: data.current.palette.surfaceContainer),
                      child: AnimatedSize(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeInOut,
                          child: expand[index] ? dailyExpanded(day, data, data.current.palette, _onExpandTapped, index)
                              : dailyCollapsed(data, day, data.current.palette, index, daysToShow, _onExpandTapped)
                      )
                  ),
                );
              }
          ),
        ],
      ),
    );
  }
}

Widget dailyCollapsed(var data, var day, ColorScheme palette, int index, int daysToShow, onExpandTapped) {
  return GestureDetector(
    behavior: HitTestBehavior.translucent,
    onTap: () {
      onExpandTapped(index);
    },
    child: Padding(
      padding: EdgeInsets.only(left: 21, right: 20,
        top: index == 0 ? 22 : 21, //evens out the top and bottom sizes with bigger border radii
        bottom: index == (daysToShow - 1) ? 22 : 21
      ),
      child: Row(
        children: [
          SizedBox(
            width: 45,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                comfortatext(day.name.split(", ")[0], 19,
                    data.settings,
                    color: palette.secondary),
                comfortatext(day.name.split(", ")[1], 13,
                    data.settings,
                    color: palette.outline),
              ],
            ),
          ),
          Icon(day.icon, size: 37, color: palette.onSurface,),
          SizedBox(
            width: 40,
            child: Align(
              alignment: Alignment.centerRight,
              child: comfortatext("${day.minTemp.toString()}°", 18, data.settings, color: palette.primary)
            ),
          ),
          Expanded(
            child: Container(
              margin: const EdgeInsets.only(left: 14, right: 14),
              height: 16,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: palette.surfaceContainerHighest
              ),
              child: LayoutBuilder(
                builder: (BuildContext context, BoxConstraints constraints) {
                  final double width = constraints.maxWidth;

                  final lowest = data.dailyMinMaxTemp[0];
                  final highest = data.dailyMinMaxTemp[1];
                  const double smallest = 18;
                  final double minPercent = min(max((day.rawMinTemp - lowest) / (highest - lowest), 0), 1);
                  final double maxPercent = min(max((day.rawMaxTemp - lowest) / (highest - lowest), 0), 1);
                  return Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      margin: EdgeInsets.only(left: min(width * minPercent, width - smallest)),
                      width: max(smallest, (maxPercent - minPercent) * width),
                      height: 16,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: palette.secondaryFixedDim
                      ),
                    ),
                  );
                }
              ),
            )
          ),
          comfortatext("${day.maxTemp.toString()}°", 18, data.settings, color: palette.primary),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Icon(Icons.expand_more, size: 22, color: palette.secondary,),
          )
        ],
      ),
    ),
  );
}


Widget dailyExpanded(var day, data, ColorScheme palette, onExpandTapped, index) {

  return Padding(
    padding: const EdgeInsets.only(left: 13, right: 13, top: 0, bottom: 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () {
            onExpandTapped(index);
          },
          child: Padding(
            padding: const EdgeInsets.only(top: 23, bottom: 23),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const SizedBox(width: 8,),
                comfortatext("${day.name.split(", ")[0]}, ", 19, data.settings, color: palette.secondary),
                comfortatext(day.name.split(", ")[1], 14, data.settings, color: palette.outline),
                const Spacer(),
                Icon(Icons.expand_less, size: 22, color: palette.secondary,),
                const SizedBox(width: 9,),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 20, left: 6, right: 10),
          child: Row(
            children: [
              Icon(day.icon, size: 38, color: palette.onSurface,),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: comfortatext(day.text, 22, data.settings, color: palette.primary),
              ),
              const Spacer(),
              Icon(Icons.keyboard_double_arrow_down, size: 16, color: palette.outline,),
              comfortatext("${day.minTemp.toString()}°", 19, data.settings, color: palette.primary),
              const SizedBox(width: 6,),
              Icon(Icons.keyboard_double_arrow_up, size: 16, color: palette.outline,),
              comfortatext("${day.maxTemp.toString()}°", 19, data.settings, color: palette.primary)
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            //color: palette.secondaryContainer,
            border: Border.all(color: palette.outlineVariant, width: 2),
            borderRadius: BorderRadius.circular(18),
          ),
          padding: const EdgeInsets.only(left: 10, right: 10, top: 25, bottom: 25),
          margin: const EdgeInsets.all(2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              dayStat(data, Icons.umbrella_rounded, day.precip_prob, "%"),
              dayStat(data, Icons.water_drop_outlined, day.total_precip, data.settings["Precipitation"], iconSize: 16.5),
              dayStat(data, Icons.air, day.windspeed, data.settings["Wind"], addWind: true,
                  windDir: day.wind_dir),
              dayStat(data, Icons.wb_sunny_outlined, day.uv, "uv"),
            ],
          ),
        ),

        Padding(
          padding: const EdgeInsets.only(top: 20),
          child: NewHourly(data: data, hours: day.hourly, addDayDivider: false, elevated: true,),
        )

      ],
    ),
  );
}