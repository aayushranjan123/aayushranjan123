# UI-UX-design-Email-template-project-using-figma
UI/UX design Email template project using figma

An email template is a pre-designed email that can be used to send out
 marketing or promotional emails. The goal of a good email template is to make it
 easy and quick for businesses to send out emails that look professional and
 engaging.
 
 A good email template should be:
 
 Visually appealing: The email template should be visually appealing and easy to read. The
 use of colors, fonts, and images should be carefully considered to create a visually
 appealing email.
 
 Easy to use: The email template should be easy to use and navigate. The user should be able
 to easily find the necessary information and make changes to the template.
 
 Responsive: The email template should be responsive, so that it looks good on all devices,
 including desktop computers, laptops, tablets, and smartphones
