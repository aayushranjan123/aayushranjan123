def test_smoke():
    import edvart

    assert len(edvart.__version__) >= 3
