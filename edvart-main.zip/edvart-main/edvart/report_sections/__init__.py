"""Package consisting report sections."""
